package safestep.estructuras;

import safestep.modelo.Incidente;
import java.util.LinkedList;
import java.util.Queue;

public class ColaAlertas {
    private Queue<Incidente> cola;

    public ColaAlertas() {
        cola = new LinkedList<>();
    }

    public void encolar(Incidente inc) {
        cola.offer(inc);
    }

    public Incidente desencolar() {
        return cola.poll();
    }

    public Incidente verFrente() {
        return cola.peek();
    }

    public boolean estaVacia() {
        return cola.isEmpty();
    }

    public int tamanio() {
        return cola.size();
    }
}

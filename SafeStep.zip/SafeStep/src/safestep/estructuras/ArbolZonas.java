package safestep.estructuras;

import safestep.modelo.Zona;
import java.util.ArrayList;
import java.util.List;

public class ArbolZonas {

    private class Nodo {
        Zona zona;
        Nodo izq, der;
        Nodo(Zona z) { zona = z; }
    }

    private Nodo raiz;

    public void insertar(Zona zona) {
        raiz = insertarRec(raiz, zona);
    }

    private Nodo insertarRec(Nodo nodo, Zona zona) {
        if (nodo == null) return new Nodo(zona);
        double peligro = zona.getNivelPeligroPromedio();
        if (peligro < nodo.zona.getNivelPeligroPromedio())
            nodo.izq = insertarRec(nodo.izq, zona);
        else
            nodo.der = insertarRec(nodo.der, zona);
        return nodo;
    }

    // Recorrido inorden: zonas de menor a mayor peligro
    public List<Zona> zonasOrdenadas() {
        List<Zona> lista = new ArrayList<>();
        inorden(raiz, lista);
        return lista;
    }

    private void inorden(Nodo nodo, List<Zona> lista) {
        if (nodo == null) return;
        inorden(nodo.izq, lista);
        lista.add(nodo.zona);
        inorden(nodo.der, lista);
    }

    // Zonas más seguras (izquierda del árbol)
    public List<Zona> zonasSeguras() {
        List<Zona> todas = zonasOrdenadas();
        List<Zona> seguras = new ArrayList<>();
        for (Zona z : todas)
            if (z.getNivelPeligroPromedio() < 2.5) seguras.add(z);
        return seguras;
    }
}

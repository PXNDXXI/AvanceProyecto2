package safestep.estructuras;

import safestep.modelo.Incidente;
import java.util.ArrayList;
import java.util.List;

public class ListaIncidentes {
    private NodoLista<Incidente> cabeza;
    private int tamanio;

    public ListaIncidentes() {
        cabeza = null;
        tamanio = 0;
    }

    // CREAR
    public void agregar(Incidente inc) {
        NodoLista<Incidente> nuevo = new NodoLista<>(inc);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoLista<Incidente> actual = cabeza;
            while (actual.siguiente != null)
                actual = actual.siguiente;
            actual.siguiente = nuevo;
        }
        tamanio++;
    }

    // LEER por ID
    public Incidente buscarPorId(int id) {
        NodoLista<Incidente> actual = cabeza;
        while (actual != null) {
            if (actual.dato.getId() == id) return actual.dato;
            actual = actual.siguiente;
        }
        return null;
    }

    // LEER por zona
    public List<Incidente> buscarPorZona(String zona) {
        List<Incidente> resultado = new ArrayList<>();
        NodoLista<Incidente> actual = cabeza;
        while (actual != null) {
            if (actual.dato.getZona().equalsIgnoreCase(zona))
                resultado.add(actual.dato);
            actual = actual.siguiente;
        }
        return resultado;
    }

    // ELIMINAR
    public boolean eliminar(int id) {
        if (cabeza == null) return false;
        if (cabeza.dato.getId() == id) {
            cabeza = cabeza.siguiente;
            tamanio--;
            return true;
        }
        NodoLista<Incidente> actual = cabeza;
        while (actual.siguiente != null) {
            if (actual.siguiente.dato.getId() == id) {
                actual.siguiente = actual.siguiente.siguiente;
                tamanio--;
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    // OBTENER TODOS
    public List<Incidente> obtenerTodos() {
        List<Incidente> lista = new ArrayList<>();
        NodoLista<Incidente> actual = cabeza;
        while (actual != null) {
            lista.add(actual.dato);
            actual = actual.siguiente;
        }
        return lista;
    }

    // ORDENAR por nivel de riesgo (burbuja)
    public List<Incidente> ordenarPorRiesgo() {
        List<Incidente> lista = obtenerTodos();
        int n = lista.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (lista.get(j).getNivelRiesgo() < lista.get(j+1).getNivelRiesgo()) {
                    Incidente temp = lista.get(j);
                    lista.set(j, lista.get(j+1));
                    lista.set(j+1, temp);
                }
            }
        }
        return lista;
    }

    public int getTamanio() { return tamanio; }
}
package safestep.modelo;

public class Incidente {
    private int id;
    private String tipoRiesgo;    // "Robo", "Acoso", "Sin iluminación", etc.
    private String zona;
    private String descripcion;
    private long timestamp;
    private boolean esVerificado;
    private int nivelRiesgo;      // 1 (bajo) a 5 (alto)

    public Incidente(int id, String tipoRiesgo, String zona,
                     String descripcion, int nivelRiesgo) {
        this.id = id;
        this.tipoRiesgo = tipoRiesgo;
        this.zona = zona;
        this.descripcion = descripcion;
        this.timestamp = System.currentTimeMillis();
        this.esVerificado = false;
        this.nivelRiesgo = nivelRiesgo;
    }

    // Getters y setters
    public int getId() { return id; }
    public String getTipoRiesgo() { return tipoRiesgo; }
    public void setTipoRiesgo(String t) { this.tipoRiesgo = t; }
    public String getZona() { return zona; }
    public void setZona(String z) { this.zona = z; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String d) { this.descripcion = d; }
    public long getTimestamp() { return timestamp; }
    public boolean isEsVerificado() { return esVerificado; }
    public void setEsVerificado(boolean v) { this.esVerificado = v; }
    public int getNivelRiesgo() { return nivelRiesgo; }
    public void setNivelRiesgo(int n) { this.nivelRiesgo = n; }

    @Override
    public String toString() {
        return "[" + id + "] " + tipoRiesgo + " - " + zona +
                " (Riesgo: " + nivelRiesgo + "/5)";
    }
}

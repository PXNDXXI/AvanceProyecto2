package safestep.modelo;

public class Zona {
    private String nombre;
    private int totalIncidentes;
    private double nivelPeligroPromedio;

    public Zona(String nombre) {
        this.nombre = nombre;
        this.totalIncidentes = 0;
        this.nivelPeligroPromedio = 0;
    }

    public String getNombre() { return nombre; }
    public int getTotalIncidentes() { return totalIncidentes; }
    public double getNivelPeligroPromedio() { return nivelPeligroPromedio; }

    public void agregarIncidente(int nivelRiesgo) {
        totalIncidentes++;
        nivelPeligroPromedio = ((nivelPeligroPromedio * (totalIncidentes - 1))
                + nivelRiesgo) / totalIncidentes;
    }

    public String getEstado() {
        if (nivelPeligroPromedio >= 4) return " PELIGROSA";
        if (nivelPeligroPromedio >= 2.5) return " MODERADA";
        return "🟢 SEGURA";
    }

    @Override
    public String toString() {
        return nombre + " | " + getEstado() +
                " | Incidentes: " + totalIncidentes;
    }
}

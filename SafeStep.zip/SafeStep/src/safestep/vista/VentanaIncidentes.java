package safestep.vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import safestep.estructuras.ColaAlertas;
import safestep.estructuras.ListaIncidentes;
import safestep.modelo.Incidente;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class VentanaIncidentes extends JFrame{
    private JPanel mainPanel;
    private JTextField txtId;
    private JTextField txtDescripcion;
    private JPanel panelSuperior;
    private JComboBox cmbTipoRiesgo;
    private JComboBox cmbZona;
    private JComboBox cmbNivelRiesgo;
    private JPanel panelBotones;
    private JButton btnAgregar;
    private JButton btnEliminar;
    private JButton btnBuscar;
    private JButton btnVerCola;
    private JButton btnOrdenar;
    private JPanel panelCentro;
    private JTable tablaIncidentes;
    private JScrollPane scrollTabla;
    private JTextArea txtAreaInfo;
    private JScrollPane scrollInfo;
    private JLabel lblEstadoCola;
    private ListaIncidentes listaIncidentes;
    private ColaAlertas colaAlertas;
    private DefaultTableModel modeloTabla;
    private int contadorId = 1;

    public VentanaIncidentes() {

        listaIncidentes = new ListaIncidentes();
        colaAlertas = new ColaAlertas();

        // TABLA
        modeloTabla = new DefaultTableModel();

        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Tipo");
        modeloTabla.addColumn("Zona");
        modeloTabla.addColumn("Descripción");
        modeloTabla.addColumn("Nivel");

        tablaIncidentes.setModel(modeloTabla);

        // COMBO TIPO RIESGO
        cmbTipoRiesgo.addItem("Robo");
        cmbTipoRiesgo.addItem("Acoso");
        cmbTipoRiesgo.addItem("Incendio");
        cmbTipoRiesgo.addItem("Accidente");
        cmbTipoRiesgo.addItem("Pelea");

        // COMBO ZONAS
        cmbZona.addItem("Centro Histórico");
        cmbZona.addItem("La Mariscal");
        cmbZona.addItem("Quitumbe");
        cmbZona.addItem("Tumbaco");
        cmbZona.addItem("Cumbayá");

        // COMBO NIVEL
        for (int i = 1; i <= 5; i++) {
            cmbNivelRiesgo.addItem(i);
        }

        // CONFIGURAR VENTANA
        setContentPane(mainPanel);
        setTitle("Gestión de Incidentes");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String descripcion = txtDescripcion.getText();
                    String tipo = cmbTipoRiesgo.getSelectedItem().toString();
                    String zona = cmbZona.getSelectedItem().toString();
                    int nivel = Integer.parseInt(
                            cmbNivelRiesgo.getSelectedItem().toString());
                    Incidente incidente = new Incidente(
                            contadorId,
                            tipo,
                            zona,
                            descripcion,
                            nivel
                    );
                    listaIncidentes.agregar(incidente);
                    colaAlertas.encolar(incidente);
                    modeloTabla.addRow(new Object[]{
                            incidente.getId(),
                            incidente.getTipoRiesgo(),
                            incidente.getZona(),
                            incidente.getDescripcion(),
                            incidente.getNivelRiesgo()
                    });
                    txtAreaInfo.setText("Incidente agregado correctamente.");
                    lblEstadoCola.setText(
                            "Alertas en cola: " + colaAlertas.tamanio());
                    txtId.setText(String.valueOf(contadorId));
                    contadorId++;
                    limpiarCampos();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(VentanaIncidentes.this,
                            "Error al agregar incidente.");
                }

            }
        });
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(txtId.getText());
                    boolean eliminado = listaIncidentes.eliminar(id);
                    if (eliminado) {
                        actualizarTabla();
                        txtAreaInfo.setText(
                                "Incidente eliminado correctamente.");
                    } else {
                        txtAreaInfo.setText(
                                "No se encontró el incidente.");
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(VentanaIncidentes.this,
                            "Ingrese un ID válido.");
                }
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(txtId.getText());
                    Incidente inc = listaIncidentes.buscarPorId(id);
                    if (inc != null) {
                        txtAreaInfo.setText(
                                "ID: " + inc.getId() +
                                        "\nTipo: " + inc.getTipoRiesgo() +
                                        "\nZona: " + inc.getZona() +
                                        "\nDescripción: " + inc.getDescripcion() +
                                        "\nNivel Riesgo: " + inc.getNivelRiesgo()
                        );
                    } else {
                        txtAreaInfo.setText(
                                "Incidente no encontrado.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(VentanaIncidentes.this,
                            "Ingrese un ID válido.");
                }
            }
        });
        btnOrdenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<Incidente> listaOrdenada =
                        listaIncidentes.ordenarPorRiesgo();
                modeloTabla.setRowCount(0);
                for (Incidente inc : listaOrdenada) {
                    modeloTabla.addRow(new Object[]{
                            inc.getId(),
                            inc.getTipoRiesgo(),
                            inc.getZona(),
                            inc.getDescripcion(),
                            inc.getNivelRiesgo()
                    });
                }
                txtAreaInfo.setText("Incidentes ordenados por riesgo.");
            }
        });
        btnVerCola.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (colaAlertas.estaVacia()) {
                    txtAreaInfo.setText(
                            "La cola de alertas está vacía.");
                    return;
                }
                Incidente frente = colaAlertas.verFrente();
                txtAreaInfo.setText(
                        "ALERTA PRIORITARIA\n\n" +
                                frente.toString()
                );
            }
        });
    }
    private void actualizarTabla() {

        modeloTabla.setRowCount(0);

        List<Incidente> lista =
                listaIncidentes.obtenerTodos();

        for (Incidente inc : lista) {

            modeloTabla.addRow(new Object[]{
                    inc.getId(),
                    inc.getTipoRiesgo(),
                    inc.getZona(),
                    inc.getDescripcion(),
                    inc.getNivelRiesgo()
            });
        }
    }
    private void limpiarCampos() {

        txtDescripcion.setText("");

        cmbTipoRiesgo.setSelectedIndex(0);

        cmbZona.setSelectedIndex(0);

        cmbNivelRiesgo.setSelectedIndex(0);
    }
}

package safestep.vista;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    public VentanaPrincipal() {

        setTitle("SafeStep");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10));

        panel.setBorder(BorderFactory.createEmptyBorder(
                20, 20, 20, 20));

        JLabel titulo = new JLabel(
                "SafeStep",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 22));

        panel.add(titulo);

        JButton btnMod2 = new JButton(
                "Gestión de Incidentes");

        JButton btnMod3 = new JButton(
                "Navegación Segura");

        JButton btnSalir = new JButton(
                "Salir");

        panel.add(btnMod2);

        panel.add(btnMod3);

        panel.add(btnSalir);

        setContentPane(panel);

        // EVENTOS
        btnMod2.addActionListener(e ->
                new VentanaIncidentes().setVisible(true));

        btnMod3.addActionListener(e ->
                new VentanaNavegacion().setVisible(true));

        btnSalir.addActionListener(e ->
                System.exit(0));
    }
}
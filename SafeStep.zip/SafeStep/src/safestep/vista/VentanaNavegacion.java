package safestep.vista;

import safestep.estructuras.ArbolZonas;
import safestep.modelo.Zona;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class VentanaNavegacion extends JFrame{
    private JPanel mainPanel;
    private JComboBox cmbOrigen;
    private JComboBox cmbDestino;
    private JButton btnCalcularRuta;
    private JButton btnVerZonasSeguras;
    private JButton btnVerArbol;
    private JLabel lblTituloRuta;
    private JTextArea txtRuta;
    private JScrollPane scrollRuta;
    private JList listaZonas;
    private JScrollPane scrollZonas;
    private DefaultListModel<String> modeloLista;

    private ArbolZonas arbolZonas;

    private List<Zona> zonasSistema;

    public VentanaNavegacion() {

        // INICIALIZAR ESTRUCTURAS
        arbolZonas = new ArbolZonas();
        zonasSistema = new ArrayList<>();
        modeloLista = new DefaultListModel<>();
        listaZonas.setModel(modeloLista);

        // CREAR ZONAS
        crearZonas();

        // LLENAR COMBOBOX
        llenarCombos();

        // CONFIGURAR VENTANA
        setContentPane(mainPanel);

        setTitle("Navegación Segura");

        setSize(850, 600);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLocationRelativeTo(null);


        btnCalcularRuta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String origen =
                        cmbOrigen.getSelectedItem().toString();
                String destino =
                        cmbDestino.getSelectedItem().toString();
                if (origen.equals(destino)) {
                    txtRuta.setText(
                            "El origen y destino no pueden ser iguales.");
                    return;
                }
                txtRuta.setText(
                        "RUTA SEGURA CALCULADA\n\n" +
                                "Origen: " + origen +
                                "\nDestino: " + destino +
                                "\n\nRuta recomendada:\n" +
                                origen +
                                " → Zona Segura Intermedia → " +
                                destino +
                                "\n\nEstado: Ruta habilitada."
                );
            }
        });
        btnVerZonasSeguras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modeloLista.clear();
                List<Zona> seguras =
                        arbolZonas.zonasSeguras();
                if (seguras.isEmpty()) {
                    modeloLista.addElement(
                            "No existen zonas seguras.");
                    return;
                }
                for (Zona z : seguras) {
                    modeloLista.addElement(
                            z.toString());
                }
                txtRuta.setText(
                        "Mostrando zonas seguras del sistema.");
            }
        });
        btnVerArbol.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modeloLista.clear();
                List<Zona> zonasOrdenadas =
                        arbolZonas.zonasOrdenadas();

                for (Zona z : zonasOrdenadas) {

                    modeloLista.addElement(
                            z.toString());
                }

                txtRuta.setText(
                        "Zonas ordenadas de menor a mayor peligro.");
            }
        });
    }
    private void crearZonas() {

        Zona z1 = new Zona("Centro Histórico");
        z1.agregarIncidente(4);
        z1.agregarIncidente(5);

        Zona z2 = new Zona("La Mariscal");
        z2.agregarIncidente(3);
        z2.agregarIncidente(4);

        Zona z3 = new Zona("Quitumbe");
        z3.agregarIncidente(2);

        Zona z4 = new Zona("Tumbaco");
        z4.agregarIncidente(1);

        Zona z5 = new Zona("Cumbayá");
        z5.agregarIncidente(1);

        zonasSistema.add(z1);
        zonasSistema.add(z2);
        zonasSistema.add(z3);
        zonasSistema.add(z4);
        zonasSistema.add(z5);

        // INSERTAR EN ÁRBOL
        arbolZonas.insertar(z1);
        arbolZonas.insertar(z2);
        arbolZonas.insertar(z3);
        arbolZonas.insertar(z4);
        arbolZonas.insertar(z5);
    }

    private void llenarCombos() {

        for (Zona z : zonasSistema) {

            cmbOrigen.addItem(z.getNombre());

            cmbDestino.addItem(z.getNombre());
        }
    }
}

